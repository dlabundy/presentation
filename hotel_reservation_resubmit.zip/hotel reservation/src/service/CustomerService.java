package service;

import model.Customer;

import java.util.ArrayList;
import java.util.List;

public class CustomerService {

    private static final ArrayList<Customer> customerArrayList = new ArrayList<>();

    public void addCustomer(String email, String firstName, String lastName){
        Customer customer = new Customer(firstName, lastName, email);
        customerArrayList.add(customer);
    }

    public Customer getCustomer(String customerEmail) {
        for (Customer customer : customerArrayList) {
            if (customer.getEmail().equals(customerEmail)) {
                return customer;
            }
        }
        return null;
    }

    public List<Customer> getAllCustomers(){
        return customerArrayList;
    }

}