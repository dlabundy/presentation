package service;

import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.*;

public class ReservationService {

    private static ReservationService reservationService = null;
    static Collection<IRoom> rooms = new HashSet<>();
    static Collection<Reservation> reservations = new HashSet<>();

    private ReservationService(){}

    public static ReservationService getInstance() {
        if (null == reservationService) {
            reservationService = new ReservationService();
        }
        return reservationService;
    }

    public static void addRoom(IRoom room){
        rooms.add(room);
    }

    public static IRoom getARoom(String roomNumber) {
        for (IRoom room : rooms) {
           if (room.getRoomNumber().equals(roomNumber)) {
                return room;
            }
        }
        return null;
    }

    public static Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {
        Reservation reservedRooms = new Reservation(customer, room, checkInDate, checkOutDate);
        reservations.add(reservedRooms);
        return reservedRooms;
    }

    public static List<IRoom> findRooms(Date checkInDate, Date checkOutDate) {
        List<IRoom> availableRooms = new ArrayList<>();
        try {
            List<IRoom> reservedRooms = occupiedRooms(checkInDate, checkOutDate);
            for (IRoom room : rooms) {
                if (!reservedRooms.contains(room)) {
                    availableRooms.add(room);
                }
            }
        } catch (Exception e) {
            if (availableRooms.isEmpty()) return null;
        }
        return availableRooms;
    }

    public static List<IRoom> occupiedRooms(Date checkInDate, Date checkOutDate) {
        List<IRoom> reservedRooms = new ArrayList<>();
        try {
            for (Reservation reservation : reservations) {
                if (reservation.getCheckInDate().getTime() <= checkInDate.getTime() &&
                        reservation.getCheckOutDate().getTime() >= checkOutDate.getTime()) {
                    reservedRooms.add(reservation.getIroom());
                }
            }
        } catch (Exception e) {
            if (reservedRooms.isEmpty()) return null;
        }
        return reservedRooms;
    }

    public static Collection<Reservation> getCustomerReservation(Customer customer) {
        Collection<Reservation> customerReservation = new ArrayList<>();
        for (Reservation reservation : reservations) {
            if (reservation.getCustomer().equals(customer)) {
                customerReservation.add(reservation);
            }
        }
        return customerReservation;
    }

    public static void printAllReservation(){
        for (Reservation reservation : reservations){
            System.out.println(reservation);
        }
    }

    public static Collection<IRoom> getAllRooms() {
        return rooms;
    }
}