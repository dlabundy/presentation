package model;

import java.util.Date;

public class Reservation {

    private Customer customer;
    private IRoom room;
    private Date checkInDate;
    private Date checkOutDate;

    public Reservation(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {
        this.customer = customer;
        this.room = room;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public IRoom getIroom() {
        return room;
    }

    public void setRoom(IRoom room) {
        this.room = room;
    }

    public Date getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(Date checkInDate) {
        this.checkInDate = checkInDate;
    }

    public Date getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(Date checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    @Override
    public int hashCode() {
        int result = 17;
        if (customer != null) {
            result = 31 * result + customer.hashCode();
        }
        if (room != null) {
            result = 31 * result + room.hashCode();
        }
        if (checkInDate != null) {
            result = 31 * result + checkInDate.hashCode();
        }
        if (checkOutDate != null) {
            result = 31 * result + checkOutDate.hashCode();
        }
        return result;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this)
            return true;
        if (!(object instanceof Reservation))
            return false;
        Reservation comparingReservation = (Reservation)object;
        boolean customerEquals = (this.customer == null && comparingReservation.customer == null)
                || (this.customer != null && this.customer.equals(comparingReservation.customer));
        boolean roomEquals = (this.room == null && comparingReservation.room == null)
                || (this.room != null && this.room.equals(comparingReservation.room));
        boolean checkInDateEquals = (this.checkInDate == null && comparingReservation.checkInDate == null)
                || (this.checkInDate != null && this.checkInDate.equals(comparingReservation.checkInDate));
        boolean checkOutDateEquals = (this.checkOutDate == null && comparingReservation.checkOutDate == null)
                || (this.checkOutDate != null && this.checkOutDate.equals(comparingReservation.checkOutDate));
        return customerEquals && roomEquals && checkInDateEquals && checkOutDateEquals;
    }

    @Override
    public String toString(){
        return "Reservation: " + "\n" + customer + "\n" + room + "\n" + checkInDate + "\n" + checkOutDate;
    }
}
