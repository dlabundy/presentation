package api;

import model.IRoom;
import model.Room;
import model.RoomType;

import java.util.*;

import static api.AdminResource.adminResource;

public class AdminMenu {

    //private static AdminResource adminResource;
    private static Scanner input;
    public List<IRoom> rooms = new ArrayList<>();

    public static void adminMenu() {
        System.out.println("----------");
        System.out.println("Admin Menu");
        System.out.println("----------");
        System.out.println("1. See all Customers");
        System.out.println("2. See all Rooms");
        System.out.println("3. See all Reservations");
        System.out.println("4. Add a Room");
        System.out.println("5. Back to Main Menu");
        System.out.println("--------------------------------------------");
        System.out.println("Please select a number for the menu option");
    }

    public static void startAdmin() {
        input = new Scanner(System.in);
        int option = 0;
        while (option < 6) {
            switch (option) {

                case 0:
                    break;

                case 1: /*OK*/
                    System.out.println(AdminResource.getAllCustomers());
                    break;

                case 2: /*OK*/
                    System.out.println(AdminResource.getAllRooms());
                    break;

                case 3:/*OK*/
                    AdminResource.displayAllReservations();
                    break;

                case 4:/*OK*/
                    addNewRoom();

                case 5:
                    MainMenu.mainMenu();

                default:
                    System.out.println("Error: Not a menu option!");
                    break;
            }
            adminMenu();
            option = input.nextInt();
        }
    }

    public static void addNewRoom(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of the new Room:");
        String roomNumber = scanner.next();
        System.out.println("Enter the type of the new Room (SINGLE/DOUBLE):");
        RoomType roomType = RoomType.valueOf(scanner.next());
        System.out.println("Enter the price of the new Room:");
        double price = scanner.nextInt();

        Room newRoom = new Room(roomNumber, price, roomType);
        List<IRoom> rooms = new ArrayList<>();
        rooms.add(newRoom);
        adminResource.addRoom(rooms);
    }
}