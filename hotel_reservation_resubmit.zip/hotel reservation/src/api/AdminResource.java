package api;

import model.Customer;
import model.IRoom;
import model.Reservation;
import service.CustomerService;
import service.ReservationService;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

public class AdminResource {

    public static final AdminResource adminResource = new AdminResource();
    public static CustomerService customerService = new CustomerService();

    public Collection<Reservation> reservations = new HashSet<>();
    public List<IRoom> rooms = new ArrayList<>();

    private AdminResource () {};

    public Customer getCustomer(String email){
        return customerService.getCustomer(email);
    }

    public static Collection<IRoom> getAllRooms() {
        return ReservationService.getAllRooms();
    }

    public static List<Customer> getAllCustomers() {
        return customerService.getAllCustomers();
    }

    public static void displayAllReservations() {
        ReservationService.printAllReservation();
    }

    public void addRoom(List<IRoom> rooms){
        for (IRoom room : rooms){
            ReservationService.addRoom(room);
        }
    }
}
