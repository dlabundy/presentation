package api;

import model.Customer;
import model.IRoom;
import model.Reservation;
import service.CustomerService;
import service.ReservationService;

import java.util.Collection;
import java.util.Date;

import static api.AdminResource.reservationService;

public class HotelResource {

    public static final CustomerService customerService = new CustomerService();

    public static Customer getCustomer(String email) {
        return customerService.getCustomer(email);
    }

    public static void createACustomer(String email, String firstName, String lastName) {
        customerService.addCustomer(email, firstName, lastName);
    }

    public static IRoom getRoom(String roomNumber) {
        return ReservationService.getARoom(roomNumber);
    }

    public static Reservation bookARoom(String customerEmail, IRoom room, Date checkInDate, Date checkOutDate) {
        Customer customer = customerService.getCustomer(customerEmail);
        if (customer == null) return null;
        return reservationService.reserveARoom(getCustomer(customerEmail), room, checkInDate, checkOutDate);
    }

    public static Collection<Reservation> getCustomersReservations(String customerEmail) {
        Customer customer = customerService.getCustomer(customerEmail);
        if (customer == null)
            System.out.println("There is no reservation with this account.");
            return ReservationService.getCustomerReservation(customer);
    }

    public static Collection<IRoom> findARoom(Date checkInDate, Date checkOutDate) {
        //Reservation reservation = (Reservation) ReservationService.findRooms(checkInDate, checkOutDate);
        //if (reservation == null) return null;
        return ReservationService.findRooms(checkInDate,checkOutDate);
    }
}
