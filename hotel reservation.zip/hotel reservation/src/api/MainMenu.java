package api;

import model.Customer;
import model.IRoom;

import service.CustomerService;
import service.ReservationService;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Scanner;

public class MainMenu {

    private static final CustomerService customerService = new CustomerService();
    private static final ReservationService reservationService = new ReservationService();
    public static Scanner input;

    public static void mainOptions() {
        System.out.println("--------------------------------------------");
        System.out.println("Welcome to the Hotel Reservation Application");
        System.out.println("--------------------------------------------");
        System.out.println("1. Find and reserve a room");
        System.out.println("2. See my reservations");
        System.out.println("3. Create an account");
        System.out.println("4. Admin");
        System.out.println("5. Exit");
        System.out.println("--------------------------------------------");
        System.out.println("Please select a number for the menu option");
    }

    public static void mainMenu() {
        mainOptions();
        input = new Scanner(System.in);
        int option = input.nextInt();

        while (option != 5){
            switch (option) {
                case 1:
                    System.out.println("You Selected to make a new Reservation");
                    findReserve();
                    break;

                case 2:
                    myReservations();
                    break;

                case 3:
                    newAccount();
                    break;

                case 4:
                    AdminMenu.startAdmin();
                    return;

                case 5:
                    input.close();
                    System.exit(0);

                default:
                    System.out.println("Error: Not a menu option!");
                    break;
            }
            mainOptions();
            option = input.nextInt();
        }
    }

    private static Collection<IRoom> findReserve() {
        Date checkOutDate = new Date();
        Date checkInDate = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter CheckIn Date DD/MM/YYYY");
        String checkIn = scanner.next();

        try {
            checkInDate = formatter.parse(checkIn);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        System.out.println("Enter CheckOut Date DD/MM/YYYY");
        String checkOut = scanner.next();

        try {
            checkOutDate = formatter.parse(checkOut);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //do you want to book a room Y/N;
        //N exit with goodbye felirat
        //Y: do you have an account?
        //Y: give me the email address
        //N: create an account
        //System.out.println(HotelResource.findARoom(checkInDate, checkOutDate));

        System.out.println("Enter room number: ");
        String roomNumber = scanner.next();
        IRoom room = HotelResource.getRoom(roomNumber);
        //System.out.println(room);
        //System.out.println(roomNumber);

        System.out.println("Enter customer email: ");
        String email = scanner.next();

        HotelResource.bookARoom(email, room, checkInDate, checkOutDate);
        System.out.println("Reservation details:");
        System.out.println(email);
        System.out.println("Room: " + roomNumber + ", " /*+ roomType*/);
        System.out.println("CheckIn: " + checkInDate);
        System.out.println("CheckOut: " + checkOutDate);
        return HotelResource.findARoom(checkInDate,checkOutDate);
    }

    private static void myReservations() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Customer Email:");
        String email = scanner.next();
        System.out.println(HotelResource.getCustomersReservations(email));
    }

    private static Customer newAccount() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Customer First Name:");
        String firstName = scanner.next();
        System.out.println("Enter Customer Last Name:");
        String lastName = scanner.next();
        System.out.println("Enter Customer Email:");
        String email = scanner.next();
        HotelResource.createACustomer(email, firstName, lastName);
        System.out.println("Your new account: " + email + "; " + firstName + " " + lastName);
        return new Customer(firstName, lastName, email);
    }

    public static void main(String[] args) {
        mainMenu();
    }
}
