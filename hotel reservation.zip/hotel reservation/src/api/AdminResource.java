package api;

import model.Customer;
import model.IRoom;
import model.Reservation;
import model.RoomType;
import service.CustomerService;
import service.ReservationService;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

public class AdminResource {
    public static CustomerService customerService = new CustomerService();
    public static ReservationService reservationService;

    public Collection<Reservation> reservations = new HashSet<>();
    public List<IRoom> rooms = new ArrayList<>();
    //public static Collection<Customer> customers = new HashSet<>();

    private AdminResource () {};

    public Customer getCustomer(String email){
        return customerService.getCustomer(email);
    }

    public static Collection<IRoom> getAllRooms() {
        return reservationService.getAllRooms();
    }

    public static List<Customer> getAllCustomers() {
        return customerService.getAllCustomers();
    }

    public static void displayAllReservations() {
        reservationService.printAllReservation();
    }

    public static void addRoom(List<IRoom> rooms){
        for (IRoom room : rooms){
            reservationService.addRoom(room);
        }
    }
}
