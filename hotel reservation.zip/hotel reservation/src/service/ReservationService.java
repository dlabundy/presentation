package service;

import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.*;

public class ReservationService {

    public static List<IRoom> rooms = new ArrayList<>();
    public static Collection<Reservation> reservations = new HashSet<>();


    public void addRoom(IRoom room){
        rooms.add(room);
    }

    public static IRoom getARoom(String roomNumber) {
        for (IRoom room : rooms) {
            if (room.getRoomNumber().equals(roomNumber)) {
                return room;
            }
        }
        return null;
    }

    public static Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {
        Reservation reservedRooms = new Reservation(customer, room, checkInDate, checkOutDate);
        reservations.add(reservedRooms);
        return reservedRooms;
    }

    public static Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate) {
        Set<IRoom> freeRooms = new HashSet<>();
        if (reservations.isEmpty()) {
            rooms = freeRooms;
            System.out.println(freeRooms);
            return freeRooms;
        } else {
            for (IRoom room : rooms) {
                for (Reservation reservation : reservations) {
                    if (((checkInDate.after(reservation.getCheckInDate())) && (checkInDate.before(reservation.getCheckOutDate())))
                            || (((checkOutDate.after(reservation.getCheckInDate())) && (checkInDate.before(reservation.getCheckOutDate()))))) {
                        freeRooms.add(room);
                        System.out.println(freeRooms);
                    }
                }
            }
        }
        return freeRooms;
    }

    public static Collection<Reservation> getCustomerReservation(Customer customer) {
        Collection<Reservation> customerReservation = new ArrayList<>();
        for (Reservation reservation : reservations) {
            if (reservation.getCustomer().equals(customer)) {
                customerReservation.add(reservation);
            }
        }
        return customerReservation;
    }

    public void printAllReservation(){
        for (Reservation reservation : reservations){
            System.out.println(reservation);
        }
    }

    public Collection<IRoom> getAllRooms() {
        return rooms;
    }
}
